//_jms2win_begin v1.1.9
if ( defined( 'MULTISITES_ID')) {}
else {
    $config_data .= "}\n";
}
//_jms2win_end
