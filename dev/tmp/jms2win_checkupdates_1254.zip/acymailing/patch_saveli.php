//_jms2win_begin v1.2.22
		if ( defined( 'MULTISITES_ID')) {
   		$path = ACYMAILING_BACK.'li.' . MULTISITES_ID . '.txt';
		}
//_jms2win_end
