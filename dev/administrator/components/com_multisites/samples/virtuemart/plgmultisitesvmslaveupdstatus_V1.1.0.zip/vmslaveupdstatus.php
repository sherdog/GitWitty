<?php
/**
 * @file       vmslaveupdstatus.php
 * @brief      Plugin that can be used to update the JMS slave site status when VirtueMart update an order that pertain to a slave site.
 * @version    1.1.0
 * @author     Edwin CHERONT     (e.cheront@jms2win.com)
 *             Edwin2Win sprlu   (www.jms2win.com)
 * @copyright  Joomla Multi Sites
 *             Single Joomla! 1.5.x installation using multiple configuration (One for each 'slave' sites).
 *             (C) 2008 Edwin2Win sprlu - all right reserved.
 * @license    This program is free software; you can redistribute it and/or
 *             modify it under the terms of the GNU General Public License
 *             as published by the Free Software Foundation; either version 2
 *             of the License, or (at your option) any later version.
 *             This program is distributed in the hope that it will be useful,
 *             but WITHOUT ANY WARRANTY; without even the implied warranty of
 *             MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *             GNU General Public License for more details.
 *             You should have received a copy of the GNU General Public License
 *             along with this program; if not, write to the Free Software
 *             Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *             A full text version of the GNU GPL version 2 can be found in the LICENSE.php file.
 * @par History:
 * - V1.1.0 29-OCT-2008: File creation
 */


// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.plugin.plugin' );

class plgMultisitesVMSlaveUpdStatus extends JPlugin
{
	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @access	protected
	 * @param	object	$subject The object to observe
	 * @param 	array   $config  An array that holds the plugin configuration
	 * @since	1.0
	 */
	function plgMultisitesVMSlaveUpdStatus(& $subject, $config)
	{
		parent :: __construct($subject, $config);
	}

   //------------ onOrderStatusUpdate ---------------
	function onOrderStatusUpdate( $d)
	{
      // Convert the VirtueMart status code into JMS status code
      $statusCodes = array( 'P' => 'Pending',
                            'C' => 'Confirmed',
                            'X' => 'Cancelled',
                            'R' => 'Refunded',
                            'W' => 'Pending'    // Waiting for payment confirmation (case of ClearPark)
                          );
      $order_status = $d["order_status"];
      $newStatus    = $statusCodes[ $order_status];
      
      $order_id = (int)$d["order_id"];
      
	   // Update the slave site that match the order ID and set the new status
      require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_multisites'.DS.'classes'.DS.'utils.php');
      MultisitesUtils::updateStatus( 'order_id', $order_id, $newStatus);
	}
} // End class
