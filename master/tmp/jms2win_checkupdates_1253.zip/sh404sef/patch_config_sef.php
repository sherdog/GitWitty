//_jms2win_begin v1.1.9
if ( defined( 'MULTISITES_ID') && file_exists( dirname(__FILE__) .DS. 'config.sef.' .MULTISITES_ID. '.php')) {
   include( dirname(__FILE__) .DS. 'config.sef.' .MULTISITES_ID. '.php');
} else {
//_jms2win_end
