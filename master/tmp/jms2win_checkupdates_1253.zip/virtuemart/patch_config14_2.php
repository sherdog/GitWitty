//_jms2win_begin v1.2.14
			file_put_contents( $config_filename, $config );
//_jms2win_end
/*_jms2win_undo
			file_put_contents(ADMINPATH ."virtuemart.cfg.php", $config );
  _jms2win_undo */
