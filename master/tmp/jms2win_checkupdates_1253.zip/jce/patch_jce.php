         if ( defined( 'MULTISITES_ID')) {
      	   $instance->setOverwrite( true);
         }
